﻿using System.Linq;
using System.Text.RegularExpressions;

// 1.Copying an Array
// Write code to create a copy of an array. First, start by creating an initial array. (You can use
// whatever type of data you want.) Let’s start with 10 items. Declare an array variable and
// assign it a new array with 10 items in it. Use the things we’ve discussed to put some values
// in the array.
// Now create a second array variable. Give it a new array with the same length as the first.
// Instead of using a number for this length, use the Length property to get the size of the
// original array.
// Use a loop to read values from the original array and place them in the new array. Also
// print out the contents of both arrays, to be sure everything copied correctly.
int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
int[] copiedNumbers = new int[numbers.Length];
// numbers.CopyTo(copiedNumbers, 0);
for (int i = 0; i < copiedNumbers.Length; i++)
{
    copiedNumbers[i] = numbers[i];
}
Console.WriteLine("Original Array: " + string.Join(", ", numbers));
Console.WriteLine("Copied Array: " + string.Join(", ", copiedNumbers));



// 2. Write a simple program that lets the user manage a list of elements. It can be a grocery list,
// "to do" list, etc. Refer to Looping Based on a Logical Expression if necessary to see how to
// implement an infinite loop. Each time through the loop, ask the user to perform an
// operation, and then show the current contents of their list. The operations available should
// be Add, Remove, and Clear. The syntax should be as follows:
// + some item
// - some item
// --
// Your program should read in the user's input and determine if it begins with a “+” or “-“ or
// if it is simply “—“ . In the first two cases, your program should add or remove the string
// given ("some item" in the example). If the user enters just “—“ then the program should
// clear the current list. Your program can start each iteration through its loop with the
// following instruction:
// Console.WriteLine("Enter command (+ item, - item, or -- to clear)):");
// List<string> lst = new List<string>();
// while (true)
// {
//     Console.WriteLine("Enter command (+ item, - item, or -- to clear)):");
//     string input = Console.ReadLine();
//     if (input.StartsWith("+ "))
//     {
//         lst.Add(input.Substring(2));
//     }
//     else if (input.StartsWith("- "))
//     {
//         lst.Remove(input.Substring(2));
//     }
//     else if (input == "--")
//     {
//         lst.Clear();
//     }
//     Console.WriteLine("Current List: " + (lst.Count > 0 ? string.Join(", ", lst) : "Empty"));
// }


// 3. Write a method that calculates all prime numbers in given range and returns them as array
// of integers
// static int[] FindPrimesInRange(startNum, endNum)
// {
// }
// Using sieve
static int[] FindPrimesInRange(int startNum, int endNum)
{
    List<int> res = new List<int>();
    List<bool> used = new List<bool>();
    for (int i = 0; i <= endNum; i++)
    {
        used.Add(false);
    }
    
    for (int i = 2; i <= endNum; i++)
    {
        if (!used[i])
        {
            
            for (int j = 2 * i; j <= endNum; j += i)
            {
                used[j] = true;
            }
            if (i >= startNum && i <= endNum)
            {
                res.Add(i);
            }
            
        }
        
    }
    return res.ToArray();
}

//Time:O(nloglogn) Space:O(n)
int[] primes = FindPrimesInRange(2, 1000);
Console.WriteLine(string.Join(", ", primes));



// 4. Write a program to read an array of n integers (space separated on a single line) and an
// integer k, rotate the array right k times and sum the obtained arrays after each rotation as shown below.
// After r rotations the element at position I goes to position (I + r) % n.
// The sum[] array can be calculated by two nested loops: for r = 1 ... k; for I = 0 ... n-1.

// Input            Output              Comments
// 3 2 4 -1         3 2 5 6             rotated1[] = -1 3 2 4
// 2                                    rotated2[] = 4 -1 3 2
//                                      sum[] = 3 2 5 6

// 1 2 3 4 5        12 10 8 6 9         rotated1[] = 5 1 2 3 4
// 3                                    rotated2[] = 4 5 1 2 3
//                                      rotated3[] = 3 4 5 1 2
//                                      sum[] = 12 10 8 6 9

static int[] GetSumAfterRotations(int[] nums, int k)
{
    int n = nums.Length;
    int[] sum = new int[n];
    for (int i = 1; i <= k; i++)
    {
        for (int j = 0; j < n; j++)
        {
            sum[(j+i) % n] += nums[j];
        }
    }
    return sum;
}

int[] nums1 = { 3, 2, 4, -1 };
int[] nums2 = { 1, 2, 3, 4, 5 };
int[] test1 = GetSumAfterRotations(nums1, 2);
int[] test2 = GetSumAfterRotations(nums2, 3);
// Output the result
Console.WriteLine("Sum of arrays after rotations: " + string.Join(" ", test1));
Console.WriteLine("Sum of arrays after rotations: " + string.Join(" ", test2));


// 5. Write a program that finds the longest sequence of equal elements in an array of integers.
// If several longest sequences exist, print the leftmost one.
// Input                        Output
// 2 1 1 2 3 3 2 2 2 1          2 2 2
// 1 1 1 2 3 1 3 3              1 1 1
// 4 4 4 4                      4 4 4 4
// 0 1 1 5 2 2 6 3 3            1 1
static int[] LongestSequenceOfEqualElements(int[] nums)
{
    List<int> res = new List<int>();
    int reslen = 0;
    int l = 0;
    int r = 0;
    while (r < nums.Length)
    {
        while (r < nums.Length-1 && nums[r] == nums[r + 1])
        {
            r++;
        }
        if ((r - l + 1) > reslen)
        {
            reslen = r - l + 1;
            res.Clear();
            for (int i = l; i <= r; i++)
            {
                res.Add(nums[i]);
            }
        }
        l = r + 1;
        r++;
    }
    return res.ToArray();
}

int[] arr1 = { 2, 1, 1, 2, 3, 3, 2, 2, 2, 1 };
int[] res1 = LongestSequenceOfEqualElements(arr1);
Console.WriteLine( string.Join(" ", res1));
int[] arr2 = { 1, 1, 1, 2, 3, 1, 3, 3 };
int[] res2 = LongestSequenceOfEqualElements(arr2);
Console.WriteLine( string.Join(" ", res2));
int[] arr3 = { 4, 4, 4, 4 };
int[] res3 = LongestSequenceOfEqualElements(arr3);
Console.WriteLine( string.Join(" ", res3));
int[] arr4 = { 0, 1, 1, 5, 2, 2, 6, 3, 3 };
int[] res4 = LongestSequenceOfEqualElements(arr4);
Console.WriteLine( string.Join(" ", res4));



// 7. Write a program that finds the most frequent number in a given sequence of numbers. In
// case of multiple numbers with the same maximal frequency, print the leftmost of them
// Input Output
// 4 1 1 4 2 3 4 4 1 2 4 9 3 The number 4 is the most frequent (occurs 5 times)
// 7 7 7 0 2 2 2 0 10 10 10 The numbers 2, 7 and 10 have the same maximal frequence (each occurs 3 times). The leftmost of them is 7.
static int MaxFreq(int[] nums)
{
    int res = 0;
    Dictionary<int, int> freq = new Dictionary<int, int>();
    int maxFreq = 0;
    for (int i = 0; i < nums.Length; i++)
    {
        if (!freq.ContainsKey(nums[i]))
        {
            freq[nums[i]] = 0;
        }
        else
        {
            freq[nums[i]]++;
        }
        if (freq[nums[i]] > maxFreq)
        {
            maxFreq = freq[nums[i]];
            res = nums[i];
        }
        
    }
    return res;
}

int[] array1 = { 4, 1, 1, 4, 2, 3, 4, 4, 1, 2, 4, 9, 3 };
int result1 = MaxFreq(array1);
Console.WriteLine(result1);
int[] array2 = { 7, 7, 7, 0, 2, 2, 2, 0, 10, 10, 10 };
int result2 = MaxFreq(array2);
Console.WriteLine(result2);



// Practice Strings
// 1. Write a program that reads a string from the console, reverses its letters and prints the
// result back at the console.
// Write in two ways
// a. Convert the string to char array, reverse it, then convert it to string again
static string Reverse(string s)
{
    char[] chars = s.ToCharArray();
    Array.Reverse(chars);
    return new string(chars);
}

string s1 = "sample";
string output1 = Reverse(s1);
Console.WriteLine(output1);
string s2 = "24tvcoi92";
string output2 = Reverse(s2);
Console.WriteLine(output2);

// b. Print the letters of the string in back direction (from the last to the first) in a for-loop
// Input                Output
// sample               elpmas
// 24tvcoi92            29iocvt42
static string Reverse2(string s)
{
    string res = "";
    for (int i = s.Length - 1; i > -1; i--)
    {
        res += s[i];
    }

    return res;
}

string s11 = "sample";
string output11 = Reverse2(s11);
Console.WriteLine(output1);
string s22 = "24tvcoi92";
string output22 = Reverse2(s22);
Console.WriteLine(output22);



// 2. Write a program that reverses the words in a given sentence without changing the punctuation and spaces
// Use the following separators between the words: . , : ; = ( ) & [ ] " ' \ / ! ? (space).
// All other characters are considered part of words, e.g. C++, a+b, and a77 are considered valid words.
// The sentences always start by word and end by separator.
// C# is not C++, and PHP is not Delphi!
// Delphi not is PHP, and C++ not is C#!
// The quick brown fox jumps over the lazy dog /Yes! Really!!!/.
// Really Yes dog lazy the over jumps fox brown /quick! The!!!/.
static string ReverseWord(string sentence)
{
    // Regex to split sentence into words and separators
    string[] parts = Regex.Split(sentence, @"(\s+|[.,:;=()\[\]""'\\\/!?\s])");
    int l = 0, r = parts.Length - 1;
    while (l < r)
    {
        if (!IsWord(parts[l]))
        {
            l++;
            continue;
        }
        if (!IsWord(parts[r]))
        {
            r--;
            continue;
        }
        string temp = parts[l];
        parts[l] = parts[r];
        parts[r] = temp;
        l++;
        r--;
    }
    return string.Join("", parts);
}

static bool IsWord(string part)
{
    return !string.IsNullOrWhiteSpace(part) && !Regex.IsMatch(part, @"^\s+|[.,:;=()\[\]""'\\\/!?\s]$");
}

string sentence1 = "C# is not C++, and PHP is not Delphi!";
string out1 = ReverseWord(sentence1);
Console.WriteLine(out1);
string sentence2 = "The quick brown fox jumps over the lazy dog /Yes! Really!!!/.";
string out2 = ReverseWord(sentence2);
Console.WriteLine(out2);


// 3. Write a program that extracts all palindromes from a given text , e.g. “ABBA”, “lamal”, “exe”
// and prints them on the console on a single line, separated by comma and space.Print all
// unique palindromes (no duplicates), sorted
// Hi,exe? ABBA! Hog fully a string: ExE. Bob
// a, ABBA, exe, ExE
static string ExtractPalindromes(string s)
{
    string[] parts = Regex.Split(s, @"(\s+|[.,:;=()\[\]""'\\\/!?\s])");
    List<string> res = new List<string>();
    foreach (var word in parts)
    {
        if (IsWord(word) && IsPalindrome(word))
        {
            res.Add(word);
        }
    }
    res.Sort();
    return string.Join(", ", res);
}

static bool IsPalindrome(string word)
{
    int l = 0, r = word.Length - 1;
    while (l < r)
    {
        if (word[l] == word[r])
        {
            l++;
            r--;
        }
        else
        {
            return false;
        }
    }
    return true;
}

string line1 = "Hi,exe? ABBA! Hog fully a string: ExE. Bob";
string ans1 = ExtractPalindromes(line1);
Console.WriteLine(ans1);
string line2 = "a, ABBA, exe, ExE";
string ans2 = ExtractPalindromes(line2);
Console.WriteLine(ans2);



// 4. Write a program that parses an URL given in the following format: [protocol]://[server]/[resource]
// The parsing extracts its parts: protocol, server and resource.
//      The [server] part is mandatory.
//      The [protocol] and [resource] parts are optional.
// https://www.apple.com/iphone
// [protocol] = "https"
// [server] = "www.apple.com"
// [resource] = "iphone"

// ftp://www.example.com/employee
// [protocol] = "ftp"
// [server] = "www.example.com"
// [resource] = "employee"

// https://google.com
// [protocol] = "https"
// [server] = "google.com"
// [resource] = ""

// www.apple.com
// [protocol] = ""
// [server] = "www.apple.com"
// [resource] = ""

static string ParseeURL(string s)
{
    string protocol = "";
    string server = "";
    string resource = "";
    int protocolEndIndex = s.IndexOf("://");
    if (protocolEndIndex != -1)
    {
        protocol = s.Substring(0, protocolEndIndex);
        s = s.Substring(protocolEndIndex + 3); // Remove protocol part
    }
    int resourceStartIndex = s.IndexOf('/');
    if (resourceStartIndex != -1)
    {
        server = s.Substring(0, resourceStartIndex);
        resource = s.Substring(resourceStartIndex + 1); // Exclude the '/'
    }
    else
    {
        server = s; // The rest is the server if no resource exists
    }
    
    return $"[protocol] = \"{protocol}\"\n" +
           $"[server] = \"{server}\"\n" +
           $"[resource] = \"{resource}\"";
}

string url1 = "https://www.apple.com/iphone";
string o1 = ParseeURL(url1);
Console.WriteLine(o1);
string url2 = "ftp://www.example.com/employee";
string o2 = ParseeURL(url2);
Console.WriteLine(o2);
string url3 = "https://google.com";
string o3 = ParseeURL(url3);
Console.WriteLine(o3);
string url4 = "www.apple.com";
string o4 = ParseeURL(url4);
Console.WriteLine(o4);