namespace hw_03.DataModel;
using hw_03.Interfaces;
// is a Person
// Belongs to one Department and he can be Head of the Department
// Instructor will have added bonus salary based on his experience, calculate his years of experience based on Join Date

public class Instructor: Person, IInstructorService
{
    public string Department { get; set; }
    
    public bool IsHeadOfDepartment { get; set; }
    public DateTime JoinDate { get; set; }
    public decimal BonusPerYearExperience { get; set; }
    
    public Instructor(string name, DateTime dateofbirth, decimal baseSalary,DateTime joinDate, decimal bonusPerYearExperience):base(name,dateofbirth,baseSalary)
    {
        JoinDate = joinDate;
        BonusPerYearExperience = bonusPerYearExperience;
    }
    
    public override decimal CalculateSalary()
    {
        int experience = DateTime.Now.Year - JoinDate.Year;
        return BonusPerYearExperience + experience * BonusPerYearExperience;
    }
}