using hw_03.Interfaces;

namespace hw_03.DataModel;
// Will have list of enrolled students
public class Course: ICourseService
{
    public string CourseName { get; set; }
    private List<Student> EnrolledStudents = new List<Student>();

    public void AddStudent(Student student)
    {
        EnrolledStudents.Add(student);
    }

    public List<string> ShowStudentNameList()
    {
        List<string> NameList = new List<string>();
        foreach (var student in EnrolledStudents)
        {
            NameList.Add(student.Name);
            
        }

        return NameList;
    }
}