using hw_03.Interfaces;

namespace hw_03.DataModel;
// is a Person
// has no salary
// Can take multiple courses
// Calculate student GPA based on grades for courses
// Each course will have grade from A to F
public class Student: Person, IStudentService
{
    private Dictionary<string, char> CourseGrades { get; set; } = new Dictionary<string, char>();

    public Student(string name, DateTime dateofbirth, decimal baseSalary): base(name,dateofbirth,baseSalary)
    {
    }
    public void AddCourses(string course, char grade)
    {
        CourseGrades[course] = grade;
    }
    

    public decimal CalculateGpa()
    {
        if (CourseGrades.Count == 0) return 0;
        
        decimal totalPoints = 0;
        foreach (var grade in CourseGrades.Values)
        {
            totalPoints += GradeToPoint(grade);
        }

        return totalPoints / CourseGrades.Count;
    }

    private decimal GradeToPoint(char grade)
    {
        switch (grade)
        {
            case 'A':
                return 4.0m;
            case 'B':
                return 3.0m;
            case 'C':
                return 2.0m;
            case 'D':
                return 1.0m;
            case 'F':
                return 0.0m;
            default:
                Console.WriteLine("Invalid Grade");
                return 0.0m;
        }
        // return grade switch
        // {
        //     'A' => 4.0m,
        //     'B' => 3.0m,
        //     'C' => 2.0m,
        //     'D' => 1.0m,
        //      _ => 0.0m
        //
        // };
    }

    public override decimal CalculateSalary()
    {
        return 0;
    }
}