using hw_03.Interfaces;

namespace hw_03.DataModel;
// Will have one Instructor as head
// Will have Budget for school year (start and end Date Time)
// Will offer list of courses
public class Department: IDepartmentService
{
    public string DepartmentName;
    
    private Instructor Head;

    public DateTime SchoolStartDate{ get; set; }
    
    public DateTime SchoolEndDate { get; set; }
    
    public decimal Budget { get; set; }
    
    private List<Course> CourseList = new List<Course>();
    
    public void AddCourse(Course course)
    {
        CourseList.Add(course);
    }

    public List<string> ShowCourseList()
    {
        List<string> NameList = new List<string>();
        foreach (var crs in CourseList)
        {
            NameList.Add(crs.CourseName);
            
        }

        return NameList;
    }
}