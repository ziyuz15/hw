namespace hw_03.DataModel;
using hw_03.Interfaces;
// Calculate Age of the Person
// Calculate the Salary of the person, Use decimal for salary
// Salary cannot be negative number
// Can have multiple Addresses, should have method to get addresses

public abstract class Person: IPersonService
{
    public string Name { get; set; }
    private DateTime DateOfBirth { get; set; }
    
    private List<string> Addresses = new List<string>();
    
    private decimal BaseSalary { get; set; }
    
    public Person(string name, DateTime dateOfBirth, decimal baseSalary)
    {
        if (baseSalary < 0) throw new ArgumentException("Salary cannot be negative.");
        Name = name;
        DateOfBirth = dateOfBirth;
        BaseSalary = baseSalary;
    }
    public int CalculateAge()
    {
        return DateTime.Now.Year - DateOfBirth.Year;
    }

    public void AddAddress(string addr)
    {
        Addresses.Add(addr);
    }
    
    public List<string> GetAddress()
    {
        return Addresses;
    }
    
    
    public abstract decimal CalculateSalary();
}