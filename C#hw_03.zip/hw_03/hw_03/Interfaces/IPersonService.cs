namespace hw_03.Interfaces;

public interface IPersonService
{
    string Name { get; set; }
    int CalculateAge();
    void AddAddress(string addr);
    // List<string> GetAddresses();
    decimal CalculateSalary();
    
}