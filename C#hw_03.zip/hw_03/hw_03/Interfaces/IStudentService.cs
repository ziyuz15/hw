namespace hw_03.Interfaces;

public interface IStudentService: IPersonService
{
    void AddCourses(string course, char grade);
    decimal CalculateGpa();
}