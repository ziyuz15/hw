namespace hw_03.Interfaces;

public interface IInstructorService: IPersonService
{
    string Department { get; set; }
    bool IsHeadOfDepartment { get; set; }
    public DateTime JoinDate { get; set; }
    decimal BonusPerYearExperience { get; set; }
}