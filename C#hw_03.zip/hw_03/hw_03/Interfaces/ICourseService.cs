namespace hw_03.Interfaces;

public interface ICourseService
{
    
}