namespace hw03_Q7;
// Color class:
// A constructor that takes a red, green, blue, and alpha value.
// A constructor that takes just red, green, and blue, while alpha defaults to 255 (opaque).
// Methods to get and set the red, green, blue, and alpha values from a Color instance.
// A method to get the grayscale value for the color, which is the average of the red, green and blue values.

public class Color
{
    private int Red { get; set; }
    private int Green{ get; set; }
    private int Blue{ get; set; }
    private int Alpha{ get; set; }

    public Color(int red, int green, int blue, int alpha=255)
    {
        this.Red = ValidateColorValue(red);
        this.Green = green;
        this.Blue = blue;
        this.Alpha = alpha;
    }

    public int GetGrayScale()
    {
        return (Red + Green + Blue) / 3;
    }

    private int ValidateColorValue(int val)
    {
        if (val > 255 || val < 0)
        {
            throw new ArgumentException("Color values must be between 0 and 255");
        }

        return val;
    }
}