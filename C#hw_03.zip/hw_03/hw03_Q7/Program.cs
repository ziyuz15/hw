﻿using hw03_Q7;
// 7. Try creating the two classes below, and make a simple program to work with them, as described below

// Create a Color class:
// On a computer, colors are typically represented with a red, green, blue, and alpha (transparency) value, usually in the range of 0 to 255.
// Add these as instance variables.
// A constructor that takes a red, green, blue, and alpha value.
// A constructor that takes just red, green, and blue, while alpha defaults to 255 (opaque).
// Methods to get and set the red, green, blue, and alpha values from a Color instance.
// A method to get the grayscale value for the color, which is the average of the red, green and blue values.

// Create a Ball class:
// The Ball class should have instance variables for size and color (the Color class you just created).
// Let’s also add an instance variable that keeps track of the number of times it has been thrown.
// Create any constructors you feel would be useful.
// Create a Pop method, which changes the ball’s size to 0.
// Create a Throw method that adds 1 to the throw count, but only if the ball hasn’t been popped (has a size of 0).
// A method that returns the number of times the ball has been thrown.

// Write some code in your Main method to create a few balls, throw them around a few times, pop a few, and try to throw them again,
// and print out the number of times that the balls have been thrown. (Popped balls shouldn’t have changed.)
Color redColor = new Color(255, 0, 0);
Color blueColor = new Color(0, 0, 255);
Color greenColor = new Color(0, 255, 0);

// Create Balls
Ball redBall = new Ball(10, redColor);
Ball blueBall = new Ball(15, blueColor);
Ball greenBall = new Ball(20, greenColor);

// Throw Balls
redBall.Throw();
redBall.Throw();
blueBall.Throw();
greenBall.Throw();
greenBall.Pop(); // Pop green ball

// Try throwing the popped ball
greenBall.Throw(); // Should not increment throw count

// Print Throw Counts
Console.WriteLine($"Red Ball Throw Count: {redBall.GetThrowCount()}");
Console.WriteLine($"Blue Ball Throw Count: {blueBall.GetThrowCount()}");
Console.WriteLine($"Green Ball Throw Count: {greenBall.GetThrowCount()}");