namespace hw03_Q7;
// Ball class:
// The Ball class should have instance variables for size and color (the Color class you just created).
// Let’s also add an instance variable that keeps track of the number of times it has been thrown.
// Create any constructors you feel would be useful.
// Create a Pop method, which changes the ball’s size to 0.
// Create a Throw method that adds 1 to the throw count, but only if the ball hasn’t been popped (has a size of 0).
// A method that returns the number of times the ball has been thrown.
public class Ball
{
        private decimal Size { get; set; }
        private Color Color { get; set; }
        private int ThrownTimes { get; set; }

        public Ball(decimal size, Color color)
        {
                this.Size = size;
                this.Color = color;
                this.ThrownTimes = 0;
        }

        public void Pop()
        {
                this.Size = 0;
        }

        public void Throw()
        {
                if (this.Size > 0) this.ThrownTimes++;
        }
        
        public int GetThrowCount()
        {
                return this.ThrownTimes;
        }
}