namespace hw_04;
using System;
using System.Collections.Generic;
using hw_04;
// 3. Implement a GenericRepository<T> class that implements IRepository<T> interface that will have common /CRUD/ operations
//  so that it can work with any data source such as SQL Server, Oracle, In-Memory Data etc.
// Make sure you have a type constraint on T were it should be of reference type and can be of type Entity which has one property called Id.
// IRepository<T> should have following methods
// 1. void Add(T item)
// 2. void Remove(T item)
// 3. Void Save()
// 4. IEnumerable<T> GetAll()
// 5. T GetById(int id)
public class GenericRepository<T>: IRepository<T> where T: Entity
{
    private List<T> entityList = new List<T>();
    public void Add(T item)
    {
        entityList.Add(item);
    }

    public void Remove(T item)
    {
        entityList.Remove(item);
    }

    public void Save()
    {
        Console.WriteLine("Changes saved.");
    }

    public IEnumerable<T> GetAll()
    {
        return entityList;
    }

    public T GetById(int id)
    {
        foreach (var entity in entityList)
        {
            if (entity.Id == id)
            {
                return entity;
            }
        }

        return null;
    }
}