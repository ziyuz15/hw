﻿// 1. Create a custom Stack class MyStack<T> that can be used with any data type which has following methods
// 1. int Count()
// 2. T Pop()
// 3. Void Push()

using hw_04;

MyStack<int> stack = new MyStack<int>();
stack.Push(1);
stack.Push(2);
Console.WriteLine(stack.Count());
stack.Pop();
Console.WriteLine(stack.Count());


// 2. Create a Generic List data structure MyList<T> that can store any data type. Implement the following methods.
// 1. void Add (T element)
// 2. T Remove (int index)
// 3. bool Contains (T element)
// 4. void Clear ()
// 5. void InsertAt (T element, int index)
// 6. void DeleteAt (int index)
// 7. T Find (int index)
MyList<int> myIntList = new MyList<int>();

myIntList.Add(10);
myIntList.Add(20);
myIntList.Add(30);
myIntList.PrintAll(); // Output: MyList Contents: 10, 20, 30

Console.WriteLine($"Removed: {myIntList.Remove(1)}"); // Output: Removed: 20
myIntList.PrintAll(); // Output: MyList Contents: 10, 30

Console.WriteLine($"Contains 30: {myIntList.Contains(30)}"); // Output: Contains 30: True

myIntList.InsertAt(25, 1);
myIntList.PrintAll(); // Output: MyList Contents: 10, 25, 30

myIntList.DeleteAt(0);
myIntList.PrintAll(); // Output: MyList Contents: 25, 30

Console.WriteLine($"Element at index 1: {myIntList.Find(1)}"); // Output: Element at index 1: 30

myIntList.Clear();
myIntList.PrintAll();


// 3. Implement a GenericRepository<T> class that implements IRepository<T> interface that will have common /CRUD/ operations
//  so that it can work with any data source such as SQL Server, Oracle, In-Memory Data etc.
// Make sure you have a type constraint on T were it should be of reference type and can be of type Entity which has one property called Id.
// IRepository<T> should have following methods
// 1. void Add(T item)
// 2. void Remove(T item)
// 3. Void Save()
// 4. IEnumerable<T> GetAll()
// 5. T GetById(int id)
GenericRepository<Product> productRepository = new GenericRepository<Product>();

productRepository.Add(new Product { Id = 1, Name = "Laptop", Price = 1200.00m });
productRepository.Add(new Product { Id = 2, Name = "Smartphone", Price = 800.00m });


Console.WriteLine("All Products:");
foreach (var product in productRepository.GetAll())
{
    Console.WriteLine($"Id: {product.Id}, Name: {product.Name}, Price: {product.Price}");
}


var productById = productRepository.GetById(1);
Console.WriteLine($"\nProduct with ID 1: Name: {productById.Name}, Price: {productById.Price}");


productRepository.Remove(productById);
productRepository.Save();


Console.WriteLine("\nRemaining Products:");
foreach (var product in productRepository.GetAll())
{
    Console.WriteLine($"Id: {product.Id}, Name: {product.Name}, Price: {product.Price}");
}