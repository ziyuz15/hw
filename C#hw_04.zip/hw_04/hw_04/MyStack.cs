namespace hw_04;
// 1. Create a custom Stack class MyStack<T> that can be used with any data type which has following methods
// 1. int Count()
// 2. T Pop()
// 3. Void Push()
using System;
using System.Collections.Generic;
public class MyStack<T>
{
    private List<T> Stack = new List<T>();
    public int Count()
    {
        return Stack.Count;
    }

    public T Pop()
    {
        if (Stack.Count == 0)
        {
            throw new InvalidOperationException("stack is empty");
        }

        T PopedItem = Stack[Stack.Count - 1];
        Stack.RemoveAt(Stack.Count-1);
        return PopedItem;
    }

    public void Push(T item)
    {
        Stack.Add(item);
    }
}