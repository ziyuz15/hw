namespace hw_04;

public class Entity
{
    public int Id { get; set; }
    
}