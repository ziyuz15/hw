namespace hw_04;
using System;
using System.Collections.Generic;

// 2. Create a Generic List data structure MyList<T> that can store any data type. Implement the following methods.
// 1. void Add (T element)
// 2. T Remove (int index)
// 3. bool Contains (T element)
// 4. void Clear ()
// 5. void InsertAt (T element, int index)
// 6. void DeleteAt (int index)
// 7. T Find (int index)

public class MyList<T>
{
    private List<T> myList;

    public MyList()
    {
        myList = new List<T>();
    }
    
    public void Add(T item)
    {
        myList.Add(item);
    }

    public T Remove(int index)
    {
        if (index < 0 || index > myList.Count)
        {
            throw new ArgumentOutOfRangeException("index out of range");
        }
        T item = myList[index];
        myList.RemoveAt(index);
        return item;
    }

    public bool Contains(T element)
    {
        return myList.Contains(element);
    }

    public void Clear()
    {
        myList.Clear();
    }

    public void InsertAt(T element, int index)
    {
        if (index < 0 || index > myList.Count)
        {
            throw new ArgumentOutOfRangeException("index out of range");
        }
        myList.Insert(index,element);
    }

    public void DeleteAt(int index)
    {
        if (index < 0 || index > myList.Count)
        {
            throw new ArgumentOutOfRangeException("index out of range");
        }
        myList.RemoveAt(index);
    }

    public T Find(int index)
    {
        if (index < 0 || index > myList.Count)
        {
            throw new ArgumentOutOfRangeException("index out of range");
        }
        return myList[index];
    }

    public void PrintAll()
    {
        Console.WriteLine(string.Join(", ", myList));
    }
    
}